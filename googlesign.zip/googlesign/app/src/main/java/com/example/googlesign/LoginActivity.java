package com.example.googlesign;

import android.content.Intent;
//import android.support.annotation.NonNull;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    EditText myemail1;
    EditText mypass1;
    private FirebaseAuth mAut;
    Button login;

    @Override
    protected void onStart() {
        mypass1.setText("");
        super.onStart();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        mAut = FirebaseAuth.getInstance();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        myemail1=(EditText) findViewById(R.id.email1);
        mypass1=(EditText) findViewById(R.id.pass);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menu1,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.button2:
                Intent intent3=new Intent(LoginActivity.this,MainActivity.class);
                startActivity(intent3);

            default:return super.onOptionsItemSelected(item);
        }

    }
    public void loginn(View view){
        if(myemail1.length()>4 && mypass1.length()>4){
            final String myeamil=myemail1.getText().toString();
            final String mypassword=mypass1.getText().toString();


            mAut.signInWithEmailAndPassword(myeamil, mypassword)
                    .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                // Sign in success, update UI with the signed-in user's information
                                Log.i("TAG", "signInWithEmail:success");
                                FirebaseUser user = mAut.getCurrentUser();
                                String userid=user.getUid().toString();
                                Toast.makeText(LoginActivity.this,"Authentication successful",Toast.LENGTH_SHORT).show();
                                Log.i("user","user:"+user.toString());
                                Log.i("user","user:"+userid);
                                myemail1.setText("");
                                mypass1.setText("");
                                Intent intent2=new Intent(LoginActivity.this,logouttest.class);
                                startActivity(intent2);
                            } else {
                                // If sign in fails, display a message to the user.
                                Log.i("TAG", "signInWithEmail:failure", task.getException());
                                Toast.makeText(LoginActivity.this, "Authentication failed.",
                                        Toast.LENGTH_SHORT).show();

                            }

                            // ...
                        }
                    });

        }

        else{Toast.makeText(LoginActivity.this, "Please fill the username and password",
                Toast.LENGTH_SHORT).show();}}
    public void backbut(View view){
        Intent intent3=new Intent(LoginActivity.this,MainActivity.class);
        startActivity(intent3);
    }

}
