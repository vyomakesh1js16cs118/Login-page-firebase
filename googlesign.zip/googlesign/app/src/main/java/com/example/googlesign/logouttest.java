package com.example.googlesign;
import android.content.DialogInterface;
import android.content.Intent;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class logouttest extends AppCompatActivity {
    FirebaseAuth mAuth;
    FirebaseAuth.AuthStateListener mAuthlistener;

    @Override
    protected void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthlistener);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menu2,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.item2:FirebaseAuth.getInstance().signOut();
                Intent intent1=new Intent(logouttest.this,MainActivity.class);
                startActivity(intent1);
                Toast.makeText(this,"signout",Toast.LENGTH_SHORT).show();

            default:return super.onOptionsItemSelected(item);
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        mAuth=FirebaseAuth.getInstance();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logouttest);
        mAuthlistener=new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                if (firebaseAuth.getCurrentUser()==null){
                    startActivity(new Intent(logouttest.this,MainActivity.class));
                }
            }
        };
    }

    @Override
    public void onBackPressed() {

        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setMessage("List will be deleted \n Are you sure you want to go back? ")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //add intent
                        FirebaseAuth.getInstance().signOut();
                        Intent intent1=new Intent(logouttest.this,MainActivity.class);
                        startActivity(intent1);
                        Toast.makeText(logouttest.this,"signout",Toast.LENGTH_SHORT).show();

                        //  logouttest.super.onBackPressed();
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
        AlertDialog alertDialog=builder.create();
        alertDialog.show();



    }

    public void logout(View view){
        FirebaseAuth.getInstance().signOut();
        Intent intent1=new Intent(logouttest.this,MainActivity.class);
        startActivity(intent1);
        Toast.makeText(this,"signout",Toast.LENGTH_SHORT).show();
    }
}
